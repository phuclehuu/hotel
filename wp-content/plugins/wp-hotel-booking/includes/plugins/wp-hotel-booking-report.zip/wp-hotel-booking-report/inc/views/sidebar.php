<ul class="chart-legend">
	<li style="border-color: #b1d4ea" class="highlight_series tips" data-series="5">
		<strong><span class="amount">£0.00</span></strong> gross sales in this period
	</li>
	<li style="border-color: #3498db" class="highlight_series tips" data-series="6">
		<strong><span class="amount">£0.00</span></strong> net sales in this period
	</li>
	<li style="border-color: #dbe1e3" class="highlight_series " data-series="1" data-tip="">
		<strong>0</strong> orders placed
	</li>
	<li style="border-color: #ecf0f1" class="highlight_series " data-series="0" data-tip="">
		<strong>0</strong> items purchased
	</li>
		<li style="border-color: #e74c3c" class="highlight_series " data-series="7" data-tip="">
	<strong><span class="amount">£0.00</span></strong> refunded 0 orders (0 items)								</li>
		<li style="border-color: #5cc488" class="highlight_series " data-series="4" data-tip="">
	<strong><span class="amount">£0.00</span></strong> charged for shipping								</li>
		<li style="border-color: #f1c40f" class="highlight_series " data-series="3" data-tip="">
	<strong><span class="amount">£0.00</span></strong> worth of coupons used								</li>
</ul>